package com.example.greenoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.core.app.NotificationCompat

class OverlayService : Service() {

    private var windowManager: WindowManager? = null
    private var overlayLayout: View? = null

    companion object {
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        private const val CHANNEL_ID = "OverlayServiceChannel"
        private const val NOTIFICATION_ID = 101

        var isRunning = false
            private set
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopOverlay()
            stopSelf()
            return START_NOT_STICKY
        }

        startForegroundNotification()
        showOverlay()
        return START_STICKY
    }

    private fun showOverlay() {
        if (overlayLayout != null) return // Already showing

        // Create transparent container layout
        val container = FrameLayout(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
        }

        // Create the 10-pixel wide bright green line (#00FF00) spanning MATCH_PARENT height
        val greenLine = View(this).apply {
            setBackgroundColor(Color.parseColor("#00FF00"))
        }

        // Layout parameters for the child line inside the container positioned at X=300
        val lineParams = FrameLayout.LayoutParams(
            10, // 10 pixels wide
            FrameLayout.LayoutParams.MATCH_PARENT // MATCH_PARENT height
        ).apply {
            leftMargin = 300 // Positioned at X = 300
            topMargin = 0
        }
        container.addView(greenLine, lineParams)

        // WindowManager layout params as specified:
        // - TYPE_APPLICATION_OVERLAY (API 26+) / TYPE_PHONE fallback
        // - FLAG_NOT_FOCUSABLE (allows interaction underneath)
        // - FLAG_NOT_TOUCH_MODAL (passes touches outside bounds through to apps below)
        // - Format TRANSLUCENT (transparent background)
        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val windowParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            windowManager?.addView(container, windowParams)
            overlayLayout = container
            isRunning = true
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun stopOverlay() {
        if (overlayLayout != null) {
            try {
                windowManager?.removeView(overlayLayout)
            } catch (e: Exception) {
                e.printStackTrace()
            }
            overlayLayout = null
        }
        isRunning = false
    }

    private fun startForegroundNotification() {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Green Line Overlay Active")
            .setContentText("Overlay is running over apps at X=300")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Green Overlay Service Channel",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notification to keep overlay alive in background"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopOverlay()
    }
}