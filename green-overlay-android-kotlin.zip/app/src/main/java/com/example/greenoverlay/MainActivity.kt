package com.example.greenoverlay

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var btnToggleService: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvPermissionNotice: TextView

    // Register Activity Result launcher for Settings.ACTION_MANAGE_OVERLAY_PERMISSION
    private val overlayPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        checkAndHandlePermission()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        btnToggleService = findViewById(R.id.btnToggleService)
        tvStatus = findViewById(R.id.tvStatus)
        tvPermissionNotice = findViewById(R.id.tvPermissionNotice)

        btnToggleService.setOnClickListener {
            handleToggleClick()
        }

        // Ask the user to grant permission at startup if not already granted
        checkAndHandlePermission(promptUser = true)
    }

    override fun onResume() {
        super.onResume()
        updateUiState()
    }

    private fun checkAndHandlePermission(promptUser: Boolean = false): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                if (promptUser) {
                    showPermissionExplanationDialog()
                }
                updateUiState()
                return false
            }
        }
        updateUiState()
        return true
    }

    private fun showPermissionExplanationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Permission Required")
            .setMessage("This app needs permission to display over other apps to show the green overlay line. Please enable 'Display over other apps' on the next screen.")
            .setPositiveButton("Grant Permission") { _, _ ->
                requestOverlayPermission()
            }
            .setNegativeButton("Cancel") { dialog, _ ->
                dialog.dismiss()
                Toast.makeText(this, "Permission denied. Overlay cannot be shown.", Toast.LENGTH_LONG).show()
            }
            .setCancelable(false)
            .show()
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            overlayPermissionLauncher.launch(intent)
        }
    }

    private fun handleToggleClick() {
        if (!checkAndHandlePermission(promptUser = true)) {
            return
        }

        if (OverlayService.isRunning) {
            stopOverlayService()
        } else {
            startOverlayService()
        }
        updateUiState()
    }

    private fun startOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
        Toast.makeText(this, "Overlay Service Started", Toast.LENGTH_SHORT).show()
    }

    private fun stopOverlayService() {
        val intent = Intent(this, OverlayService::class.java).apply {
            action = OverlayService.ACTION_STOP
        }
        startService(intent)
        Toast.makeText(this, "Overlay Service Stopped", Toast.LENGTH_SHORT).show()
    }

    private fun updateUiState() {
        val hasPermission = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            Settings.canDrawOverlays(this)
        } else {
            true
        }

        if (!hasPermission) {
            tvPermissionNotice.text = "Permission required: Please allow 'Display over other apps'"
            tvPermissionNotice.visibility = TextView.VISIBLE
            btnToggleService.text = "Grant Permission"
            tvStatus.text = "Status: Permission Needed"
            tvStatus.setTextColor(getColor(android.R.color.holo_red_dark))
            return
        }

        tvPermissionNotice.visibility = TextView.GONE

        if (OverlayService.isRunning) {
            tvStatus.text = "Status: Overlay Active (X=300, W=10px, #00FF00)"
            tvStatus.setTextColor(getColor(android.R.color.holo_green_dark))
            btnToggleService.text = "Stop Overlay Service"
        } else {
            tvStatus.text = "Status: Overlay Inactive"
            tvStatus.setTextColor(getColor(android.R.color.darker_gray))
            btnToggleService.text = "Start Overlay Service"
        }
    }
}