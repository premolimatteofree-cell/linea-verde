# Green Line Overlay - Native Android Kotlin App

A native Android application written in Kotlin that draws a fixed permanent vertical line overlay over all other applications using Android's `WindowManager` and `SYSTEM_ALERT_WINDOW`.

## Features Requested & Implemented
1. **Manifest Permission**: Declares `android.permission.SYSTEM_ALERT_WINDOW` and foreground service permissions in `AndroidManifest.xml`.
2. **Startup Permission Prompt**: `MainActivity` checks `Settings.canDrawOverlays(context)` at startup and directs the user to grant permission via `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.
3. **Background Service (`OverlayService`)**:
   - Uses `WindowManager.LayoutParams` with:
     - `TYPE_APPLICATION_OVERLAY` (API 26+)
     - `FLAG_NOT_FOCUSABLE` (allows touches to focus apps underneath)
     - `FLAG_NOT_TOUCH_MODAL` (passes touch events outside window boundaries to lower windows)
     - `PixelFormat.TRANSLUCENT` (transparent background)
   - Vertical line: **10 pixels wide**, bright green (**#00FF00**), **MATCH_PARENT** in height.
   - Position: Fixed at **X = 300** pixels.
4. **Simple Main Activity**: Screen with live status and a **Start/Stop Service** toggle button.

## How to Run in Android Studio
1. Download or copy the project files into a standard Android Studio directory.
2. Open the project folder in Android Studio.
3. Sync Gradle and ensure Kotlin 1.9+ and Android SDK 34 are installed.
4. Click **Run** on an emulator or connected physical Android device.
5. On first launch, the app prompts you to allow "Display over other apps". Enable it and return to the app.
6. Press **Start Overlay Service**. The green vertical line appears at X=300 and remains permanently across all apps (Home screen, Chrome, YouTube, etc.)!

## Quick ADB Commands
```bash
# Grant overlay permission directly via ADB (skips manual UI prompt):
adb shell appops set com.example.greenoverlay SYSTEM_ALERT_WINDOW allow

# Start the OverlayService manually:
adb shell am start-foreground-service -a ACTION_START com.example.greenoverlay/.OverlayService

# Stop the OverlayService:
adb shell am start-service -a ACTION_STOP com.example.greenoverlay/.OverlayService
```
